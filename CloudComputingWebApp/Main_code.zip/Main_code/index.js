const fetch = require('cross-fetch')
const express = require('express')
var chatDBVal = require('./chatdb.js')
const app = express()
const cors = require('cors')
app.use(cors())
var port = process.env.PORT || 8080;

const http = require('http').Server(app).listen(port)
const axios = require('axios')
var qs = require('qs')

app.use(express.static('static'))
app.use(express.urlencoded({ extended: false }))

//app.listen(port, () =>
console.log(`HTTP Server with Express.js is listening on port:${port}`)

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/static/index.html');
})

const io = require('socket.io')(http);
console.log("socket.io server is running on port " + port);

io.on('connection', (socketclient) => {
    console.log('A new client is connected!');
    socketclient.authenticated = false;
    socketclienthandler(socketclient);
})

function BroadcastAuthenticatedClients(event, message){
    var sockets = io.sockets.sockets;

    for (var id in sockets){
        const socketclient = sockets[id];

        if(socketclient && socketclient.authenticated){
            list = ListAuthenticatedClients(socketclient)
            socketclient.emit(event, message);
        }
    }
}

function BroadcastAuthenticatedClients2(event, user){
    var sockets = io.sockets.sockets;
    let currentuname = user["username"];
    let currentfname = user["fullname"];

    for (var id in sockets){
        const socketclient = sockets[id];

        if(socketclient && socketclient.authenticated && (socketclient.username != currentuname)){
            console.log(`broadcast list 2 : `, socketclient.username)
            list = ListAuthenticatedClients(socketclient)

            socketclient.emit(event, list);
        }
    }
}

function socketclienthandler(socketclient) {

        var onlineClients = Object.keys(io.sockets.sockets).length;
        console.log(`Online Clients count: ${onlineClients}`);
        var welcomemessage = `${socketclient.id} is connected! Number of connected clients: ${onlineClients}`;
        console.log(welcomemessage);

        BroadcastAuthenticatedClients("online", welcomemessage)

        socketclient.on("message", (data) => {
            console.log('Data from a client: ' + data);
            console.log(`socketclient.authenticated: `, socketclient.authenticated);

            BroadcastAuthenticatedClients("message", `${socketclient.id} says: ${data}`)
        });

        socketclient.on('privatechat', (receiver, message) => {

            console.log(`in index.js pvtmessage: `, receiver, message)

            var sockets = io.sockets.sockets;
            let sender = socketclient.username;

            var messageJson = {
                "sender": sender,
                "receiver": receiver,
                "message": message,
                "timestamp": Date.now()
            }

            console.log("messageJson - ",messageJson)

            for ( var id in sockets){
            const socketclient = sockets[id];

            if(socketclient && socketclient.authenticated && socketclient.username == receiver){
                    list = ListAuthenticatedClients(socketclient)
                    socketclient.emit('privatechat', sender, message, list);

                    chatDBVal.storePrivateMessage(messageJson)
                }
            }
        })

        socketclient.on("typing", () => {
            console.log(`${socketclient.id} is typing ...`);
            BroadcastAuthenticatedClients("typing", `${socketclient.id} is typing ...`)
        });

        socketclient.on('get_chat_history',(reveiver)=>{
            chatDBVal.loadPrivateMessage(socketclient.username,reveiver,(result)=>{
                socketclient.emit('chathistory',reveiver,result)
            })
        });

        socketclient.on('update', (user) => {
            BroadcastAuthenticatedClients2('update', user);
        })

        socketclient.on('disconnect', () => {
            var onlineClients = Object.keys(io.sockets.sockets).length;
            var byemessage = `${socketclient.id} is disconnected! Number of connected clients: ${onlineClients}`;
            console.log(byemessage);

            var sockets = io.sockets.sockets;

            for (var id in sockets){
                const socketclient = sockets[id];

                if(socketclient && socketclient.authenticated){
                    console.log(`broadcast list in disconnect : `, socketclient.username)
                    list = ListAuthenticatedClients(socketclient)

                    console.log(`list in disconnect: `, list)
                    socketclient.emit("offline", byemessage, list);
                }
            }
        });

        socketclient.on("loginuser", (username, password) => {
            login(username,password,(isAuth,username,fullname)=>{
                if(isAuth){
                    socketclient.authenticated = true
                    socketclient.username = username
                    socketclient.fullname = fullname
                    var userObj = {
                        "username":username,
                        "fullname":fullname,
                        "avatar":"https://i.pravatar.cc/50?u="+username
                    }
    
                    console.log('user =>', userObj)
                    socketclient.emit("login",userObj)

                    BroadcastAuthenticatedClients("onlineusers",ListAuthenticatedClients())
                                        
                    BroadcastAuthenticatedClients("updateusers",ListAuthenticatedClients())                    
                    
                }else{
                    socketclient.emit("login-error",username)
                }
            })
        })  
        
        socketclient.on("chatbot-message",(data)=>{

            var messageJson = {
                "sender": socketclient.username,
                "receiver": "m_chatbot",
                "message": data,
                "timestamp": Date.now()
            }

            chatDBVal.storePrivateMessage(messageJson)
            
            query({"inputs": {
                "text": data
            }}).then((response) => {
            console.log(JSON.stringify(response));
            var resJson = {
                "sender": "m_chatbot",
                "receiver": socketclient.username,
                "message": response["generated_text"],
                "timestamp": Date.now()
            }
            chatDBVal.storePrivateMessage(resJson)

            socketclient.emit("chatbot-message","m_chatbot",response["generated_text"])
        });
        })

        socketclient.on("create",(username,password,fullname,email)=>{
            register((username,password,fullname,email),(isUserSaved,message)=>{
                if(isUserSaved){
                    socketclient.emit("signup successful",message)
                }else{
                    socketclient.emit("signup error",message)
                }
            })
        })

}

function ListAuthenticatedClients(){
    var sockets = io.sockets.sockets;
    let onlineUsers = new Map();

    chatbotprofile = { "username": "m_chatbot", "fullname": "ChatBot",
        "avatar": "https://i.pravatar.cc/150?u=iChatBot" }

    onlineUsers.set("m_chatbot", chatbotprofile)

    for ( var id in sockets){
        const socketclient = sockets[id];

        if(socketclient && socketclient.authenticated){
            profile = { username: socketclient.username, fullname: socketclient.fullname,
                        avatar: "https://i.pravatar.cc/150?u="+socketclient.username }
            onlineUsers.set(socketclient.username, profile)
        }
    }

    console.log(`onlineUsers 1: `, onlineUsers)

    let onlineUsersJSON = [];

    onlineUsers.forEach((key, value) => {
    console.log(`key: `, key)
        onlineUsersJSON.push(key);
    })

    console.log(`list in method 1 : `, onlineUsersJSON);

    return onlineUsersJSON;
}

register("pushpa","fire","pushpa raj","fire@ab.com")


async function register(username,password,fullname,email,callback){
    console.log("username "+username)
    console.log("password "+password)
    console.log("fullname "+fullname)
    console.log("email "+email)

    const axios = require("axios")
    axios.get('https://cca-sprint3-account-microservices.azurewebsites.net/registeruser/'+username+'/'+password+'/'+fullname+'/'+email )
      .then(function (response) {
        console.log("response - "+response)
        if(response.data.acknowledged){
            return callback(true,"User Registered. Please Login")
        }else{
            return callback(false,"Unable to register user.")
        }
      })
      .catch(function (error1) {
        console.log("Error - "+error1.data.error)
        return callback(false,error1.response.data.error)
    })
}


async function login(username, password,callback){
    const axios = require("axios")
    axios.get('https://cca-sprint3-account-microservices.azurewebsites.net/signin/'+username+'/'+password)
    .then((response)=>{
        console.log("response - "+response.status)
        console.log("user "- response.data.username)
        if(response.data.username === username){
            console.log("response user present")
            return callback(true,username,response.data.fullname)
        }
        else{
            console.log("response user not present")
            return callback(false,"Login Failed!")
        }  
    })
}


async function query(data) {
	const response = await fetch(
		"https://api-inference.huggingface.co/models/microsoft/DialoGPT-large",
		{
			headers: { Authorization: "Bearer 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" },
			method: "POST",
			body: JSON.stringify(data),
		}
	);
	const result = await response.json();
	return result;
}


