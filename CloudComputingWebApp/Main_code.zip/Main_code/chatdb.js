const MongoClient = require('mongodb').MongoClient;
const mongourl = "mongodb+srv://cca-hemadriv1:vinay20199609@cca-hemadriv1.4mphd.mongodb.net/cca-labs?retryWrites=true&w=majority";
const dbClient = new MongoClient(mongourl, { useNewUrlParser: true, useUnifiedTopology: true });

dbClient.connect(err => {
    if (err) throw err;
    console.log("Connected to the MongoDB cluster");
})

module.exports.storePrivateMessage = (privatechat)=>{

    const db = dbClient.db("cca-labs")

    db.collection("chat_messages").insertOne( privatechat, (err, result) =>{
        if(err){
            console.log("Microservice-Error");
        }else{
            console.log("chat saved Successfully!");
        }
    })
}

module.exports.loadPrivateMessage = (s_sender,s_receiver, callback) => {
    
    const db = dbClient.db("cca-labs")

            db.collection("chat_messages").find({
                $or:[ {sender:s_sender, receiver:s_receiver},
                    {sender:s_receiver, receiver:s_sender}]
            }).sort({timestamp:-1}).limit(100).toArray(function(err,result){
                console.log("chat history - ", result)
                if(result){
                    result.reverse()
                    return callback(result)
                }
            })
}