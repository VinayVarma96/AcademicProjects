# README #

#CCA - Cloud Computing and Applications

#Instructor - Phu H. Phung

###Department of Computer Science
###University of Dayton

Name - Spoorthi Hosahalli Rajavijaykumar
ID - 1017103300
Email - rajavijaykumars1@udayton.edu

>Lab0 setup complete