var shown = false;
function showHiddenEmail(){
    if(shown){
        document.getElementById('email').innerHTML = "Show our email";
        shown = false;
    }else{
        var myemail = "<a herf='mailto:rajavijaykumars1"+"@"+"udayton.edu'>rajavijaykumars1"+"@"+"udayton.edu</a>";
        document.getElementById('email').innerHTML = myemail;
        shown = true;
    }
}