const express=require('express')
const app=express()
var port= process.env.PORT || 8080;
app.use(express.urlencoded({extended:false}))
const cors=require('cors')
app.use(cors())
app.listen(port,() =>
console.log('Http Server with Express.js is listening on port: ${port}'))

app.get('/',(req,res)=>{
    res.send('Microservice gateway by Abhinava K. Tumukunta and Vinay V. Hemadri. Usage: host/Age_ChineseZodiac?year=xxxx')
})
app.get('/Age_ChineseZodiac', function(req, res){
    var result;
    result=new Date().getFullYear() - req.query.data;
    res.send('You are '+result+' years old!')
});
app.get('/microservice1',(req,res)=>{
    res.send("microservice 1 result = "+req.query.data)
})
app.get('/microservice2', function(req, res){
    var num1= req.query.a
    var num2= req.query.b
    if (num1 > num2)
    {
        numerator = num1;
        denominator = num2;
    }
    else
    {
        numerator = num2;
        denominator = num1;
    }
    remainder = numerator % denominator;
    while (remainder != 0)
    {
        numerator   = denominator;
        denominator = remainder;
        remainder   = numerator % denominator;
    }
    gcd = denominator;
    lcm = num1 * num2 / gcd;
    res.send("LCM is "+lcm+", HCF is "+gcd)
});